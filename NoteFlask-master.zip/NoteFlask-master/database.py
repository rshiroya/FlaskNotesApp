from flask_sqlalchemy import SQLAlchemy

# Intitialize the Flask-SQLAlchemy extension instance
db = SQLAlchemy()
